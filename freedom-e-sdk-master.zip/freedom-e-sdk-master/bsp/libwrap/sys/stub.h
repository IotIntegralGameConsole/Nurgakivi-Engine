/* See LICENSE of license details. */
#ifndef _SIFIVE_SYS_STUB_H
#define _SIFIVE_SYS_STUB_H

static inline int _stub(int err)
{
  return -1;
}

#endif /* _SIFIVE_SYS_STUB_H */
