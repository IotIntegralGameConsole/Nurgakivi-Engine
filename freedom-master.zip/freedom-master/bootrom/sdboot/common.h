#ifndef _SDBOOT_COMMON_H
#define _SDBOOT_COMMON_H

#ifndef PAYLOAD_DEST
  #define PAYLOAD_DEST MEMORY_MEM_ADDR
#endif


#endif
